#include <stdio.h>

void	ft_putnbr_base(int nb, char *base);

int	main(void)
{
	printf("bases binarias, n = 47.\n");
	ft_putnbr_base(47, "01");
	printf("\nEsperado: 101111\n");
}