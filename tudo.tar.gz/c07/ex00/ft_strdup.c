#include <stdlib.h>

char	*ft_strdup(char *src)
{
	char	*dest;
	int		count;
	int		i;

	i = 0;
	count = 0;
	while (*(src + count) != '\0')
	{
		count++;
	}
	dest = (char *) malloc(sizeof(char) * count);
	if (dest == 0)
		return (0);
	while (*(src + i) != '\0')
	{
		dest[i] = src[i];
		i++;
	}
	dest[i] = '\0';
	return (dest);
}
