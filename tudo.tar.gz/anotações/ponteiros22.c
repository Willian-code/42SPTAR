/*Função malloc():
Serve para alocar memória durante a
execução do programa.
Ela faz o pedido de memória ao computador
e retorna um ponteiro com o endereço do 
início do espaço de memória alocado.*/
//Protótipo:

#include <stdio.h>
#include <stdlib.h>

int main()
{
	void* malloc(unsigned int num);

	return (0);
}