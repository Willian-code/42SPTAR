/*Uma variável é uma posição de memória 
que armazena um dado que pode ser usado
pelo programa.
Deve ser declarada durante o 
desenvolvimento do programa.*/

#include <stdio.h>
#include <stdlib.h>

int main()
{
	int x, y;
	float c;
	char nome[50];

	return (0);
}
