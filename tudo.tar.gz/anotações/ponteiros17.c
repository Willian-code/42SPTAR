#include <stdio.h>

int	main(int argc, char **argv)
{
	(void) argc;
	(void) argv;
	printf("Número de argumento: %d\n",argc);
	printf("Valor do argumento: %s\n", argv[0]);

	char *str = argv[1];
	printf("Valor do argumento: %s\n", str);
	return (0);	
}
/*1- Depois de compilar manda o comando "echo $?"
no terminal, para verificar se o seu programa
é executado até o fim e sem problemas.

2- Por convenção é importante retornar zero
no fim do seu main, para dizer que tudo que
está acima está certo.

3- argc (arg count) indica o número de parâmetros 
que daremos para o nosso programa. O número de 
parâmetros incui o nome do programa.

4- argv (arg value) é um ponteiro de endereço de
um pool no início de cada parâmetro que daremos 
em parâmetro 
*/