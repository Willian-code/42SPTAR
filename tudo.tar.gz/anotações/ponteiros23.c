/*Funcionamento:
a função malloc() recebe por parâmetro
- A quantidade de bytes a ser alocada.
e retorna.
- NULL: no caso de erro.
- Ponteiro para a primeira posição do array.*/

#include <stdio.h>
#include <stdlib.h>

int main()
{
	//Exemplo:
	//Cria array de 50 inteiros (200 bytes)
	int *v = malloc(200);
	//Cria array de 200 char (200 bytes)
	char *c = malloc(200);

	return (0);
}