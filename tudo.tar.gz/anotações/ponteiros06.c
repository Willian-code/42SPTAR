#include <stdio.h>

int main()
{
	/*Sobre o valor de endreço armazenado por um ponteiro podemos apenas somar e subrarir valores INTEIROS*/
}