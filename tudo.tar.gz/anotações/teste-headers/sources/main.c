#include <stdio.h>
#include "calculos.h"

int main()
{
	int y = 5;
	int sq = square(y);
	int c = cube(y);

	printf("O quadrado de %d: %d\n", y, sq);
	printf("Cubo de %d: %d\n", y, c);
	printf("Valor da constante PI: %f\n", _PI);

	return (0);
}