#ifndef   CALCULOS_H 
# define CALCULOS_H

# define _PI 3.14159265
int square(int x);
int cube(int x);

#endif