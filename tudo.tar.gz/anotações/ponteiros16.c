#include <stdio.h>

int	main(int argc, char **argv)
{
	(void) argc;
	(void) argv;
	printf("Número de argumentos: %d\n", argc);
	printf("Valor do argumento: %s\n", argv[1]);

	char	*str = argv[1];
	printf("%s\n", str);
	return (0);
}
