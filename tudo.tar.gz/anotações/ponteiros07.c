#include <stdio.h>

int	main()
{
	/*Alinguagem C permite criar ponteiros
	com diferentes níveis de apotamento:
	ponteiros que pontam para outros ponteiros.*/   
	int	x = 10;
	int *ptr1;
	int	**ptr2;
	
	ptr1 = &x;
	ptr2 = &ptr1;
	//Endereço em ptr2
	printf("ptr2: %p\n", ptr2);//&ptr1
	//Conteudo do endereço
	printf("*ptr2: %p\n", *ptr2);//x&
	//Conteudo do endereço do endereço
	printf("**ptr2: %d\n", **ptr2);//x
	printf("ptr1: %p\n", ptr1);

	return (0);
}