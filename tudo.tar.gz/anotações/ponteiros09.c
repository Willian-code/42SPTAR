#include <stdio.h>

int main()
{
	/*Acessando o endereço de um
	ponteiro para ponteiro*/
	char	letra = 'a';
	char	*ptrChar = &letra;
	char	**ptrPtrChar = &ptrChar;
	char	***ptrPtr = &ptrPtrChar;

	printf("*ptrChar: %p\n", ptrChar);
	printf("**ptrPtrChar: %p\n", ptrPtrChar);
	printf("**ptrPtr: %p\n", ptrPtr);

	return (0);
}