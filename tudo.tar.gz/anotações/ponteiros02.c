#include <stdio.h>

int	main(void)
{
	/*Ponteiros não inicializados
	apontam para um lugar indefinido.*/
	int	*p;

	/*Um ponteiro pode ter um valor 
	especial NULL, que é o endereço de nenhum lugar.*/
	int *p = NULL;
	
	return (0);
}