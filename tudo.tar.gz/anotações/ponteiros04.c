#include <stdio.h>
#include <stdlib.h>

int	main()
{
	/*O operador asterisco (*) permite
	modificar o conteúdo da posição
	de memória apontada.*/
	int	x = 10;//variável
	int *ptr;//ponteiro
	//ponteiro ptr aponta para a varável x
	ptr = &x;
	printf("x = %d\n", x);//10
	*ptr = 12;
	printf("*ptr = %d\n", *ptr);//12
	printf("x = %d\n", x);//12

	return (0);
}