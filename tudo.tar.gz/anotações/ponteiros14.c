#include <stdio.h>

int main()
{
	/*Também podemos declarar um 
	array de ponteiros*/
	//Forma geral:
	//tipo_dade *nome_array[tamanho];

	int *vet[5];//array de 5 ponteiros

	return (0);
}
