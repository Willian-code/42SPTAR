#include <stdio.h>

int main()
{
	/*Array : conjunto de dados 
	armazenados de forma sequencial.*/
	int vet[5] = {1,2,3,4,5};
	/*O nome do array é apenas um 
	ponteiro que aponta para o 
	primeiro elemento do array.*/
	int *p = vet;
	int i;
	for (i = 0; i < 5; i++)
	{
		printf("%d\n", p[i]);//Outra forma de representar p[i] é *(p+i), isso é ultilizado para acessar o conteúdo.
	}
	return (0);
}
