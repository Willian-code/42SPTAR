#include <stdio.h>
#include <stdlib.h>

int main()
{
	/*Podemos apontar o ponteiro para uma
	variável que já exista no nosso programa.*/
	int x = 10;//variável
	int *ptr;//ponteiro
	//ponteiro ptr aponta para a variável x
	ptr = &x;
	printf("x = %d\n", x);
	printf("ptr = %p\n", ptr);
	printf("*ptr = %d\n", *ptr);/*O '*' serve para declarar um ponteiro e para acessar
								o conteudo em um determinado endereço de memória*/
	return (0);
}