#include <stdio.h>

int	main()
{
	/*Atribuição: um ponteiro só pode 
	receber o endreço de uma variável
	do mesmo tipo do ponteiro*/
	int *ptr, *ptr1, x = 10;
	float y = 20.0;
	ptr = &x;
	printf("*ptr: %d\n", *ptr);
	printf("&x = %p\n", ptr);
	ptr1 = ptr;
	printf("*ptr1: %d\n", *ptr1);
	/*ptr = &y;*/

	return (0);
}