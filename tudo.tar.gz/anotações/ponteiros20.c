/*Alocar memória do tipo int é diferente
de alocar mem´ria do tipo char:
- Tipos diferentes podem ter tamanhos
diferentes na memória.*/

#include <stdio.h>
#include <stdlib.h>

int main()
{
	char: 	1 byte
	int: 	4 byte
	float: 	4 byte
	double: 8 byte

	return (0);
}