/*Se não houver memória suficiente
para alocar a mEmória resquisitada,
a função malloc() retorna NULL.*/

#include <stdio.h>
#include <stdlib.h>

int main()
{
	int *p;
	int i;
	
	p = (int*)malloc(5 * sizeof(int));
	if (p == NULL)
	{
		printf("Error: Sem Memoria!\n");
		return (1);//Termina o programa
	}
	for (i = 0; i < 5; i++)
	{
		printf("Digite p[%d]: ", i);
		scanf("%d", &p[i]);
	}
	return (0);
}