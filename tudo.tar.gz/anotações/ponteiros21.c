/* O operador sizeof() retorna o 
o número de bytes necessários para
alocar um único elemento de um 
determinado tipo de dade.*/
//Forma geral:

#include <stdio.h>
#include <stdlib.h>

int main()
{
	//sizeof(nome_do_tipo)

	//Exemplo:
	char w = sizeof(char);
	int x = sizeof(int);
	float y = sizeof(float);
	double z = sizeof(double);
	
	printf("w = %c\n", w);
	printf("x = %d\n", x);
	printf("y = %f\n", y);
	printf("z = %fl\n", z);

	return (0);
}