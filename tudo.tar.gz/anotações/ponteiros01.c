#include <stdio.h>

int	main(void)
{
	/*Forma geral de declaração
	
	Varáveis:
	tipo_varavel  nome_variavel*/
	int x;

	/*Ponteiro
	tipo_ponteiro *nome_ponteiro*/
	int	*x;

	int x, *y;
	return (0);
}