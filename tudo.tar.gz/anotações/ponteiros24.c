/*Na alocação da memória, deve-se
levar em conta o tamanho do tipo.*/
//Exemplo: criar um array de tamanho 50

#include <stdio.h>
#include <stdlib.h>

int main()
{
	int *v = (int*)malloc(200);
	char *c = (char*)malloc(50);
	//Solução: Usar sizeof()
	int *v = (int*)malloc(50 * sizeof(int));
	char *c = (char*)malloc(50 *sizeof(char));

	return (0);
	
}