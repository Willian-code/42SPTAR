#include <stdio.h>

int	main()
{
	/*Array: cinjunto de dados 
	armazenados de forma sequencial.*/
	int	vet[5] = {1,2,3,4,5};
	int *p = vet;
	int i;

	
}