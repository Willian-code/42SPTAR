#include <stdio.h>

int main()
{
	/*Acessando o endereo de um 
	elemento do array.*/
	int vet[5] = {1,2,3,4,5};

	printf("&vet[2] = %p\n", &vet[2]);
	printf("&vet[2] = %p\n", (vet + 2));

	return (0);
}