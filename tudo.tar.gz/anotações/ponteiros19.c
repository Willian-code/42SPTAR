/*Problema: precisamos construir um
programa que processe os valores
dos salários dos funcionários
de uma pequena empresa.*/
/*Solução simples: declarar um 
array bem grande.*/

#include <stdio.h>
#include <stdlib.h>

int main()
{
	float salarios[1000];

	return (0);
}

/*Considere o seguinte:
- arrays são agrupamentos sequenciais 
de dados de uma mesmo tipo na memória.
- Um ponteiro guarda o edereço de um 
dado na memória.
- O nome do array é um ponteiro para o
primeiro elemto do array.*/
/*Ideia: Posso solicitar um bloco de
memória e colocar a sua primeira posição
em um ponteiro?*/
/*A linguagem C permite alocar (reservar)
dinamicamente (em tempo de execução) blocos
de memória utilizando ponteiros. A esse
processo dá-se o nome de 
ALOCAÇÃO DINÂMICA.*/