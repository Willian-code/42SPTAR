#include <stdio.h>

char	*ft_strupcase(char *str);

int	main(void)
{
	char	lowercase[] = "lLAKJFALK";
	
	printf("-----\n1 = A lowercase contém apenas letras maiúsculas\n0 = A lowercase não contém apenas letras maiúsculas\n");
	printf("lowercase = %s\n", lowercase);
	printf("Uppercase = %s\n", ft_strupcase(lowercase));

	return (0);
}
