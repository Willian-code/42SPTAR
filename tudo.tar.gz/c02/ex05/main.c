#include <stdio.h>

int	ft_str_is_uppercase(char *str);

int	main(void)
{
	char	uppercase[] = "ALSDKFJASLKDFJSAL";
	char	special[] = "ALSKDJFLSKDFJSALFJLKSA_";
	char	empty[] = "";

	printf("-----\n1 = A string contém apenas letras maiúsculas\n0 = A string não contém apenas letras maiúsculas\n");
	printf("%s = %d\n", uppercase, ft_str_is_uppercase(uppercase));
	printf("%s = %d\n", special, ft_str_is_uppercase(special));
	printf("Empty = %d\n-----\n", ft_str_is_uppercase(empty));

	return (0);
}
