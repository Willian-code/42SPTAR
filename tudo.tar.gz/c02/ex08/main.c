#include <stdio.h>

char	*ft_strlowcase(char *str);

int	main(void)
{
	char	uppercase[] = "lLAKJFALK";
	
	printf("-----\n1 = A lowercase contém apenas letras maiúsculas\n0 = A lowercase não contém apenas letras maiúsculas\n");
	printf("Uppercase = %s\n", uppercase);
	printf("lowercase = %s\n", ft_strlowcase(uppercase));

	return (0);
}
