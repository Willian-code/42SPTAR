#include<stdio.h>

int	ft_str_is_alpha(char *str);

int	main(void)
{
	char	alpha[] = "aldfjasldfsdfasdfdfslkgjz";
	char	special[] = "ADLFKJSALKDFJ asdfas´s´s´sííí \\//!?@#21345";
	char	empty[] = "";

	printf("----\n1 = A string contem apenas letras \n0 = A string não contem apenas letras\n\n");
	printf("%s = %d\n", alpha, ft_str_is_alpha(alpha));
	printf("%s = %d\n", special, ft_str_is_alpha(special));
	printf("Empty = %d\n------\n", ft_str_is_alpha(empty));

	return (0);
}
