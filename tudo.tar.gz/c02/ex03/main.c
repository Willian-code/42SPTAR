#include <stdio.h>

int	ft_str_is_numeric(char *str);

int	main(void)
{
	char	numeric[] = "0123456789";
	char	special[] = "0123456789_";
	char	empty[] = "";

	printf("-----\n1 = A string contem apenas números\n0 = A string não contem apenas números\n");
	printf("%s = %d\n", numeric, ft_str_is_numeric(numeric));
	printf("%s = %d\n", special, ft_str_is_numeric(special));
	printf("Empty = %d\n-----\n", ft_str_is_numeric(empty));

	return (0);
}