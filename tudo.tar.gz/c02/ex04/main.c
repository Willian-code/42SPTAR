#include <stdio.h>

int	ft_str_is_lowercase(char *str);

int	main(void)
{
	char	lowercase[] = "asdkfjsasalkgdjsal";
	char	special[] = "aslkdfjsaldkjfsa_";
	char	empty[] = "";

	printf("-----\n1 = A string contém apenas letras minúsculas\n0 = A string não contém apenas letras minúsculas\n");
	printf("%s = %d\n", lowercase, ft_str_is_lowercase(lowercase));
	printf("%s = %d\n", special, ft_str_is_lowercase(special));
	printf("Empty = %d\n-----\n", ft_str_is_lowercase(empty));

	return (0);
}
