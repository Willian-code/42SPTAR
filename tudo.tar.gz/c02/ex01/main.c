#include <stdio.h>
#include <string.h>

char	*ft_strncpy(char *dest, char *src, unsigned int n);

int	main(void)
{
	char			*src;
	char			dest[12];
	unsigned int	n;

	n = 10;
	src = "Hello, world";
	printf("base: %s\n", src);
	ft_strncpy(dest, src, n);
	printf("ft_cpy : %s\n", dest);
}
