#include <stdio.h>

int	ft_str_is_printable(char *str);

int	main(void)
{
	char	string[] = "ALSDKFJASLKDFJSAL";
	char	printable[] = ":\t (tab), \a(?)";
	char	empty[] = "";
	
	printf("-----\n1 = A string contém apenas letras maiúsculas\n0 = A string não contém apenas letras maiúsculas\n");
	printf("%s = %d\n", string, ft_str_is_printable(string));
	printf("%s = %d\n", printable, ft_str_is_printable(printable));
	printf("Empty = %d\n-----\n", ft_str_is_printable(empty));

	return (0);
}
