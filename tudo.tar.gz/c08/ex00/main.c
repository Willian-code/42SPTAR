#include "ft.h"
#include <stdio.h>

int	main(void)
{
	char *str;

	str[0] = 1;
	str[1] = 2;
	str[2] = 3;
	str[3] = 4;

	printf("%d", ft_strlen(str));
	return (0);
}