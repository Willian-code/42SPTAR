#include <stdio.h>

int	ft_find_next_prime(int nb);

int	main(void)
{
	printf(" 8 = %d (11)\n", ft_find_next_prime(2147483));
}
