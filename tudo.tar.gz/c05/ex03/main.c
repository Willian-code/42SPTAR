#include <stdio.h>

int	ft_recursive_power(int nb, int power);

int	main(void)
{
	int	nb;
	int	power;

	nb = 2;
	power = 4;
	printf("%d elevado a %d = 16\n", nb, power);
	printf("%d elevado a %d = %d\n", nb, power, ft_recursive_power(nb, power));
}