#include <stdio.h>

int	ft_sqrt(int nb);

int main(void)
{
	printf("-10 = %d (0)\n", ft_sqrt(-10));
	printf("  2 = %d (0)\n", ft_sqrt(2));
	printf(" 64 = %d (8)\n", ft_sqrt(64));
}
