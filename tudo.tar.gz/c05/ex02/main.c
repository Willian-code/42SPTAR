#include <stdio.h>

int	ft_iterative_power(int nb, int power);

int	main(void)
{
	int	nb;
	int	power;

	nb = 2;
	power = 0;
	printf("%d elevado a %d = 1\n", nb, power);
	printf("%d elevado a %d = %d\n", nb, power, ft_iterative_power(nb, power));
}
