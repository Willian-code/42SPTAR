#include <stdio.h>

int	ft_is_prime(int nb);

int main(void)
{
	printf("-10 = %d (0)\n", ft_is_prime(-10));
	printf("  2 = %d (1)\n", ft_is_prime(2));
	printf(" 64 = %d (0)\n", ft_is_prime(64));
	printf("  1 = %d (0)\n", ft_is_prime(2147483646));
}