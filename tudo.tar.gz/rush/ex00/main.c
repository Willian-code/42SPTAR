#include <unistd.h>
#ifndef	UNISTD_H
# define UNISTD_H
#endif

int	is_valid_condition(char *cond);
int	rush(void);

int	main(int argc, char *argv[])
{
	if (argc != 2 || !(is_valid_condition(argv[1]) && rush()))// vai pegar se é uma argumento valido atripa de numeros que digitamos no terminal
	{
		write(1, "Error\n", 6);
	}
	return (0);
}
