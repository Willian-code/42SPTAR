////EU, JONATAS, COPIEI ESSA SOLUÇÃO DA INTERNET PARA FINS DE ESTUDOS
#include "header.h"

int		main(int argc, char **argv)
{
	int i;

	i = 0;
	ft_validation(argc, argv[1], i);
	return (0);
}