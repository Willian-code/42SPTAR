#include <unistd.h>

// gcc -Wall -Wextra -Werror tests.c
// ./a.out "4 3 2 1 1 2 2 2 4 3 2 1 1 2 2 3"

int	validate_input(char *input);

int main(int argc, char **argv)
{
    int is_valid = validate_input(argv[1]);
	if (argc == 2 && !is_valid)
	{
		write(1, "Error\n", 6);
	}
	else if (argc == 2 && is_valid)
	{
		
		write(1, "Correto\n", 8);
	}
	return (0);
}