#include <stdlib.h>

int	arr_length(char *arr)
{
	int counter;

	counter = 0;
	while (arr[counter] != '\0')
	{
		counter++;
	}
	return counter;
}

int	validate_digit(char digit)
{
	if (digit >= '1' && digit <= '4')
	{
		return (1);
	}
	return (0);
}

char	*retrieve_digits(char *input)
{
	int index;
	int count_cpy;
	int	sec_count_cpy;
	char *cpy;
	char holder;

	index = 0;
	count_cpy = 0;
	sec_count_cpy = 0;
	cpy = malloc(16);
	holder = 0;
	while (input[index] != '\0')
	{
		if (validate_digit(input[index]))
		{
			if (count_cpy <= 15)
			{
				holder = input[index];
				cpy[count_cpy] = holder;
				count_cpy++;
			}
			cpy[count_cpy + 1] = '\0';
			sec_count_cpy++;
		}
		index++;
	}
	if (sec_count_cpy != 16)
	{
		cpy[0] = '\0';
		free(cpy);
	}
	return cpy;
}

// char arr[31] = "4 3 2 1 1 2 2 2 4 3 2 1 1 2 2 2";
int	validate_input(char *input)
{
	char *retrieved;
	int retrieved_length;

	retrieved = retrieve_digits(input);
	retrieved_length = arr_length(retrieved);
	if(retrieved_length != 16)
	{
		return (0);
	}
	if (*retrieved == '\0')
	{
		return (0);
	}
	else {
		//rush(retrieved);
		return (1);
	}
	return (0);
}
