cat /etc/passwd | cut -f 1 -d : | awk 'NR%2==0' | rev | sort -r | head -n$FT_LINE2 | tail -n+$FT_LINE1 | tr '\n' ',' | sed 's#,$#.#' | sed 's/,/, /g' 
