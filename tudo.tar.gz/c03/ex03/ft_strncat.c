int	ft_strlen(char *str)
{
	int	counter;

	counter = 0;
	while (*(str + counter) != '\0')
	{
		counter++;
	}
	return (counter);
}

char	*ft_strncat(char *dest, char *src, unsigned int nb)
{
	unsigned int	i;
	unsigned int	c;

	i = 0;
	c = ft_strlen(dest);
	while (*(src + i) != '\0' && i < nb)
	{
		*(dest + c) = *(src + i);
		c++;
		i++;
	}
	*(dest + c) = '\0';
	return (dest);
}
