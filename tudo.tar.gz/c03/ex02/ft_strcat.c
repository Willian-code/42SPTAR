int	ft_strlen(char *str)
{
	int	counter;

	counter = 0;
	while (*(str + counter) != '\0')
	{
		counter++;
	}
	return (counter);
}

char	*ft_strcat(char *dest, char *src)
{
	int	c;
	int	i;

	i = 0;
	c = ft_strlen(dest);
	while (*(src + i) != '\0')
	{
		*(dest + c) = *(src + i);
		c++;
		i++;
	}
	*(dest + c) = '\0';
	return (dest);
}
