#include<unistd.h>

void	ft_putchar(char w, char x, char y)
{
	write(1, &w, 1);
	write(1, &x, 1);
	write(1, &y, 1);
	if (w != '7' || x != '8' || y != '9')
	{
		write(1, ", ", 2);
	}
}

void	ft_print_comb(void)
{
	char	w;
	char	x;
	char	y;

	w = '0';
	while (w <= '7')
	{
		x = w + 1;
		while (x <= '8')
		{
			y = x + 1;
			while (y <= '9')
			{
				ft_putchar(w, x, y);
				y++;
			}
			x++;
		}
		w++;
	}
}
