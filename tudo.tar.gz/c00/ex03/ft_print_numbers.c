#include<unistd.h>

void	ft_putchar(int n)
{
	write(1, &n, 1);
}

void	ft_print_numbers(void)
{
	int	n;

	n = 48;
	while (n <= 57)
	{
		ft_putchar(n);
		n++;
	}
}
