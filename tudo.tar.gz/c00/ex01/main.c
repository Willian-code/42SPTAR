void	ft_print_alphabet(void);

int	main(void)
{
	ft_print_alphabet();
}
