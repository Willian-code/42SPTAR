#include<unistd.h>

void	ft_putchar(int n)
{
	write(1, &n, 1);
}

void	ft_is_negative(void)
{
	int	n;

	n = 48;
	if (n >= 48)
	{
		ft_putchar('P');
	}
	else
	{
		ft_putchar('N');
	}
}
