void	ft_is_negative(void);

int	main(void)
{
	ft_is_negative();
}
