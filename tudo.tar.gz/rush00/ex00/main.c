void	rush(int x, int y);

int	main(void)
{
	rush (5, 3);
	return (0);
}
