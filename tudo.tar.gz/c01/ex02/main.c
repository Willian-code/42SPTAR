#include <stdio.h>

void	ft_swap(int *a, int *b);

int	main(void)
{
	int	a;
	int	b;

	a = 7;
	b = 3;
	printf("antes %d %d\n", a, b);
	ft_swap(&a, &b);
	printf("dopis %d %d\n", a, b);
}
