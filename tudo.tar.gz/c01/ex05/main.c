#include <stdio.h>

void	ft_putstr(char *str);

int	main(void)
{
	char	str[] = "Hello, world!yjfgbhsdgsdfgsdf1341234";

	ft_putstr(str);
}
