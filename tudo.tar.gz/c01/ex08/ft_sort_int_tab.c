void	ft_sort_int_tab(int	*tab, int	size)
{
	int	c1;
	int	c2;
	int	aux;

	c1 = 0;
	c2 = 1;
	while (c1 < size)
	{
		while (c2 < size)
		{
			if (tab[c1] > tab[c2])
			{
				aux = tab[c1];
				tab[c1] = tab[c2];
				tab[c2] = aux;
			}
			c2++;
		}
		c1++;
	}
}

#include <stdio.h>
#include <stdlib.h>

int	main(void)
{
	int *tab;
	int counter;

	srand(1);
	counter = 0;
	tab = calloc(10, sizeof(int));
	while (counter < 10)
	{
		tab[counter] = rand() % 100;
		counter++;
	}
	counter = -1;
	while (9 > counter++)
		printf("%d ", tab[counter]);
	ft_sort_int_tab(tab, 10);
	printf("%c", '\n');
	counter = -1;
	while (9 > counter++)
		printf("%d ", tab[counter]);
	printf("%c", '\n');
	return (0);
}