void	ft_rev_int_tab(int *tab, int size)
{
	int	started;
	int	aux;
	int	end;

	started = 0;
	end = size - 1;
	while (started < size / 2)
	{
		aux = tab[started];
		tab[started] = tab[end];
		tab[end] = aux;
		started++;
		end--;
	}
}
