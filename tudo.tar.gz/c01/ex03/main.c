#include <stdio.h>

void	ft_div_mod(int a, int b, int *div, int *mod);

int	main(void)
{
	int	a;
	int	b;
	int	c;
	int	d;
	int	*div;
	int	*mod;

	a = 5;
	b = 2;
	div = &c;
	mod = &d;
	ft_div_mod(a, b, div, mod);
	printf("O valor de 'a' é: %d\n", *div);
	printf("O valor de 'b' é: %d\n", *mod);
}
