#include <stdio.h>

int		ft_strlen(char *str);

int	main(void)
{
	int		count;
	char	str[] = "willian";

	count = ft_strlen(str);
	printf("%d\n", count);
}
